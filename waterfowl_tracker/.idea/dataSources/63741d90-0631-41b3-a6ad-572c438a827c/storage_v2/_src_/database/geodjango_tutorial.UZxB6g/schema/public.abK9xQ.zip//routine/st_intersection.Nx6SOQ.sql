create function st_intersection(rast1 raster, rast2 raster, nodataval double precision[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT st_intersection($1, 1, $2, 1, 'BOTH', $3)
$$;

comment on function st_intersection(raster, raster, double precision[]) is 'args: rast1, rast2, nodataval - Returns a raster or a set of geometry-pixelvalue pairs representing the shared portion of two rasters or the geometrical intersection of a vectorization of the raster and a geometry.';

alter function st_intersection(raster, raster, double precision[]) owner to postgres;

