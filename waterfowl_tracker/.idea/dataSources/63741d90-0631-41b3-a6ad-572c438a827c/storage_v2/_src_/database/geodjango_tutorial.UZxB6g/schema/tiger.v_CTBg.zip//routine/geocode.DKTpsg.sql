create function geocode(input character varying, max_results integer DEFAULT 10, restrict_geom geometry DEFAULT NULL::geometry, OUT addy norm_addy, OUT geomout geometry, OUT rating integer) returns SETOF record
    stable
    language plpgsql
as
$$
DECLARE
  rec RECORD;
BEGIN

  IF input IS NULL THEN
    RETURN;
  END IF;

  -- Pass the input string into the address normalizer
  ADDY := normalize_address(input);
  IF NOT ADDY.parsed THEN
    RETURN;
  END IF;

/*  FOR rec IN SELECT * FROM geocode(ADDY)
  LOOP

    ADDY := rec.addy;
    GEOMOUT := rec.geomout;
    RATING := rec.rating;

    RETURN NEXT;
  END LOOP;*/

  RETURN QUERY SELECT g.addy, g.geomout, g.rating FROM geocode(ADDY, max_results, restrict_geom) As g ORDER BY g.rating;

END;
$$;

alter function geocode(varchar, integer, geometry, out norm_addy, out geometry, out integer) owner to postgres;

