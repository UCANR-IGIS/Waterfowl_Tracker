create function st_approxhistogram(rast raster, nband integer, sample_percent double precision, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, TRUE, $3, 0, NULL, FALSE)
$$;

alter function st_approxhistogram(raster, integer, double precision, out double precision, out double precision, out bigint, out double precision) owner to postgres;

