create function st_colormap(rast raster, colormap text, method text DEFAULT 'INTERPOLATE'::text) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_ColorMap($1, 1, $2, $3)
$$;

comment on function st_colormap(raster, text, text) is 'args: rast, colormap, method=INTERPOLATE - Creates a new raster of up to four 8BUI bands (grayscale, RGB, RGBA) from the source raster and a specified band. Band 1 is assumed if not specified.';

alter function st_colormap(raster, text, text) owner to postgres;

