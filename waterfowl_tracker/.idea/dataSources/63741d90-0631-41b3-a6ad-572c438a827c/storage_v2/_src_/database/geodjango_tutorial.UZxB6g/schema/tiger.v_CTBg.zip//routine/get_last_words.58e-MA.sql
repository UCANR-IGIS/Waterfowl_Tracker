create function get_last_words(inputstring character varying, count integer) returns character varying
    immutable
    cost 10
    language plpgsql
as
$$
DECLARE
  tempString VARCHAR;
  result VARCHAR := '';
BEGIN
  FOR i IN 1..count LOOP
    tempString := substring(inputString from '((?: )+[a-zA-Z0-9_]*)' || result || '$');

    IF tempString IS NULL THEN
      RETURN inputString;
    END IF;

    result := tempString || result;
  END LOOP;

  result := trim(both from result);

  RETURN result;
END;
$$;

alter function get_last_words(varchar, integer) owner to postgres;

