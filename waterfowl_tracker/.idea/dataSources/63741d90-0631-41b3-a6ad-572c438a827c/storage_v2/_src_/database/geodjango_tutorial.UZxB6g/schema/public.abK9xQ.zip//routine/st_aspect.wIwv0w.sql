create function st_aspect(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, units text DEFAULT 'DEGREES'::text, interpolate_nodata boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_aspect($1, $2, NULL::public.raster, $3, $4, $5)
$$;

comment on function st_aspect(raster, integer, text, text, boolean) is 'args: rast, band=1, pixeltype=32BF, units=DEGREES, interpolate_nodata=FALSE - Returns the aspect (in degrees by default) of an elevation raster band. Useful for analyzing terrain.';

alter function st_aspect(raster, integer, text, text, boolean) owner to postgres;

