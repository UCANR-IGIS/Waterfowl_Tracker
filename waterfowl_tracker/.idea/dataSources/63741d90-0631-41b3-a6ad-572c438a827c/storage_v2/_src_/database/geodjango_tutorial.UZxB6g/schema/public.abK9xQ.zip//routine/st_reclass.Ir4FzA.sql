create function st_reclass(rast raster, nband integer, reclassexpr text, pixeltype text, nodataval double precision DEFAULT NULL::double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT st_reclass($1, ROW($2, $3, $4, $5))
$$;

comment on function st_reclass(raster, integer, text, text, double precision) is 'args: rast, nband, reclassexpr, pixeltype, nodataval=NULL - Creates a new raster composed of band types reclassified from original. The nband is the band to be changed. If nband is not specified assumed to be 1. All other bands are returned unchanged. Use case: convert a 16BUI band to a 8BUI and so forth for simpler rendering as viewable formats.';

alter function st_reclass(raster, integer, text, text, double precision) owner to postgres;

