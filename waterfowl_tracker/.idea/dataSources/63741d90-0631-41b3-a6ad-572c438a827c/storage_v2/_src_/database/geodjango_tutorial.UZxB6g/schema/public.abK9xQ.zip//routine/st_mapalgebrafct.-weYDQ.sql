create function st_mapalgebrafct(rast raster, pixeltype text, onerastuserfunc regprocedure) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_mapalgebrafct($1, 1, $2, $3, NULL)
$$;

comment on function st_mapalgebrafct(raster, text, regprocedure) is 'args: rast, pixeltype, onerasteruserfunc - 1 band version - Creates a new one band raster formed by applying a valid PostgreSQL function on the input raster band and of pixeltype prodived. Band 1 is assumed if no band is specified.';

alter function st_mapalgebrafct(raster, text, regprocedure) owner to postgres;

