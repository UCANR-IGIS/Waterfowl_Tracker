create function asgml(tg topogeometry, nsprefix text) returns text
    stable
    language sql
as
$$
SELECT topology.AsGML($1, $2, 15, 1, NULL);
$$;

alter function asgml(topogeometry, text) owner to postgres;

