create function _st_intersects(geom geometry, rast raster, nband integer DEFAULT NULL::integer) returns boolean
    immutable
    parallel safe
    cost 1000
    language plpgsql
as
$$
DECLARE
		hasnodata boolean := TRUE;
		_geom public.geometry;
	BEGIN
		IF public.ST_SRID(rast) != public.ST_SRID(geom) THEN
			RAISE EXCEPTION 'Raster and geometry do not have the same SRID';
		END IF;

		_geom := public.ST_ConvexHull(rast);
		IF nband IS NOT NULL THEN
			SELECT CASE WHEN bmd.nodatavalue IS NULL THEN FALSE ELSE NULL END INTO hasnodata FROM public.ST_BandMetaData(rast, nband) AS bmd;
		END IF;

		IF public.ST_Intersects(geom, _geom) IS NOT TRUE THEN
			RETURN FALSE;
		ELSEIF nband IS NULL OR hasnodata IS FALSE THEN
			RETURN TRUE;
		END IF;

		SELECT public.ST_Buffer(public.ST_Collect(t.geom), 0) INTO _geom FROM public.ST_PixelAsPolygons(rast, nband) AS t;
		RETURN public.ST_Intersects(geom, _geom);
	END;

$$;

alter function _st_intersects(geometry, raster, integer) owner to postgres;

