create function st_mapalgebra(rast raster, nband integer, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_mapalgebra(ARRAY[ROW($1, $2)]::rastbandarg[], $4, $3, 'FIRST', $5::text)
$$;

comment on function st_mapalgebra(raster, integer, text, text, double precision) is 'args: rast, nband, pixeltype, expression, nodataval=NULL - Expression version - Returns a one-band raster given one or two input rasters, band indexes and one or more user-specified SQL expressions.';

alter function st_mapalgebra(raster, integer, text, text, double precision) owner to postgres;

