create function st_buffer(geom geometry, radius double precision, quadsegs integer) returns geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$
SELECT public.ST_Buffer($1, $2, CAST('quad_segs='||CAST($3 AS text) as text))
$$;

comment on function st_buffer(geometry, double precision, integer) is 'args: g1, radius_of_buffer, num_seg_quarter_circle - Returns a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(geometry, double precision, integer) owner to postgres;

