create function _raster_constraint_info_coverage_tile(rastschema name, rasttable name, rastcolumn name) returns boolean
    stable
    strict
    language sql
as
$$
SELECT
		TRUE
	FROM pg_class c, pg_namespace n, pg_attribute a
			, (SELECT connamespace, conrelid, conkey, pg_get_constraintdef(oid) As consrc
			FROM pg_constraint) AS s
	WHERE n.nspname = $1
		AND c.relname = $2
		AND a.attname = $3
		AND a.attrelid = c.oid
		AND s.connamespace = n.oid
		AND s.conrelid = c.oid
		AND a.attnum = ANY (s.conkey)
		AND s.consrc LIKE '%st_iscoveragetile(%';

$$;

alter function _raster_constraint_info_coverage_tile(name, name, name) owner to postgres;

