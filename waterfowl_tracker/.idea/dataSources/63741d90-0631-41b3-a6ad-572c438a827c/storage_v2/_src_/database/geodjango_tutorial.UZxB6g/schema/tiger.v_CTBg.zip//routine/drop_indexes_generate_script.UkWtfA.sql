create function drop_indexes_generate_script(tiger_data_schema text DEFAULT 'tiger_data'::text) returns text
    stable
    language sql
as
$$
SELECT array_to_string(ARRAY(SELECT 'DROP INDEX ' || schemaname || '.' || indexname || ';'
FROM pg_catalog.pg_indexes  where schemaname IN('tiger',$1)  AND indexname NOT LIKE 'uidx%' AND indexname NOT LIKE 'pk_%' AND indexname NOT LIKE '%key'), E'\n');
$$;

alter function drop_indexes_generate_script(text) owner to postgres;

