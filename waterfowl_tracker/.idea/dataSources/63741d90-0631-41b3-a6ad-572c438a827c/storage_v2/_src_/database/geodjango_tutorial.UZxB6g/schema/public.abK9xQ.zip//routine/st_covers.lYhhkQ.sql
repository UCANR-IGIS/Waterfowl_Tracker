create function st_covers(rast1 raster, rast2 raster) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT public.st_covers($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_covers(raster, raster) is 'args: rastA, rastB - Return true if no points of raster rastB lie outside raster rastA.';

alter function st_covers(raster, raster) owner to postgres;

