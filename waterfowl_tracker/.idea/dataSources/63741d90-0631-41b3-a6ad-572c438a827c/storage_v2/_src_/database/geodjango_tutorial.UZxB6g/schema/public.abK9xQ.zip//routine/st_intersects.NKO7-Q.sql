create function st_intersects(rast raster, geom geometry, nband integer DEFAULT NULL::integer) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT $1::public.geometry OPERATOR(public.&&) $2 AND public._st_intersects($2, $1, $3)
$$;

comment on function st_intersects(raster, geometry, integer) is 'args: rast, geommin, nband=NULL - Return true if raster rastA spatially intersects raster rastB.';

alter function st_intersects(raster, geometry, integer) owner to postgres;

