create function st_intersection(geography, geography) returns geography
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.geography(public.ST_Transform(public.ST_Intersection(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1, $2)), public.ST_Transform(public.geometry($2), public._ST_BestSRID($1, $2))), 4326))
$$;

comment on function st_intersection(geography, geography) is 'args: geogA, geogB - Returns a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(geography, geography) owner to postgres;

